def calcular_edad(edad):
    return (2025-edad)

año=int(input("Ingrese su año de nacimiento: "))


edad = calcular_edad(año)
print(f"tu edad es:", edad , "años")




