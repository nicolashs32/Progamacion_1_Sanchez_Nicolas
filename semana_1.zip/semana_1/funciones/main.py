
nombre_usuario = input(f"Ingrese su nombre: ")
saludar(nombre_usuario)


num1 = float(input("Por favor ingrese el primer número a operar: "))
num2 = float(input("Ahora ingrese el segundo número a operar: "))

operaciones(num1, num2)


base = float(input(f"Ingrese la base del triángulo: "))
altura = float(input(f"Ingrese la altura del triángulo: "))
print(f"El área del triángulo es: {area_triangulo(base, altura)}")

