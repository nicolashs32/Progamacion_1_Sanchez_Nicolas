def saludar(nombre):
    print(f"Hola, {nombre}!")


def operaciones(num1, num2):
    print("Suma:", num1 + num2)
    print("Resta:", num1 - num2)
    print("Multiplicación:", num1 * num2)


def area_triangulo(base, altura):
    return (base * altura) / 2

