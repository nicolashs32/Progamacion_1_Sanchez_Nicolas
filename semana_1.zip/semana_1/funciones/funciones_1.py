def saludar(nombre):
    print(f"Hola, {nombre}!")

nombre_usuario = input(f"Ingrese su nombre: ")
saludar(nombre_usuario)
